SET SERVEROUTPUT ON;

DECLARE
	card NUMBER(3);
	type namesarray IS VARRAY(6) OF VARCHAR2(10);
	colName namesarray;
	total integer;
	colSize integer;
	disVal integer;
	totalSize integer := 0;

BEGIN

	SELECT count(*) into card FROM student1;
	dbms_output.put_line('----------------------------------------------');
	DBMS_OUTPUT.PUT_LINE('Cardinality of student1 fragment: ' || card);
	dbms_output.put_line('----------------------------------------------');
	
	colName := namesarray('s_id','name','department','email','password','city');
	total := colName.count;
	dbms_output.put_line('---DISTINCT NO OF ROWS IN EVERY ATTRIBUTE---');

	FOR i in 1 .. total LOOP
	  SELECT DISTINCT count(colName(i)) into disVal FROM student1;
      dbms_output.put_line('Val[' || colName(i)|| ']' || ' = ' || disVal); 
	END LOOP;
	
	dbms_output.put_line('----------------------------------------------');
	dbms_output.put_line('---MAX SIZE OF ROW FOR EVERY ATTRIBUTE---');
	
	FOR i in 1 .. total LOOP
	  SELECT max(lengthb(colName(i))) into colSize from student1;
	  
	  totalSize := totalSize + colSize;
	  
      dbms_output.put_line('Column[' || colName(i)|| ']' || ' = ' || colSize); 
    END LOOP; 
	
	dbms_output.put_line('----------------------------------------------'); 
	dbms_output.put_line('SUM OF SIZE OF ALL ATTRIBUTES : ' || totalSize); 
	dbms_output.put_line('----------------------------------------------');
 
END;
/