set serveroutput on;

DECLARE
v_msg VARCHAR2(100);

begin
proc1('Database');

end;
/