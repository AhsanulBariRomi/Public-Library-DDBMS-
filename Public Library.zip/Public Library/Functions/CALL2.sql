set serveroutput on;

DECLARE
v_msg VARCHAR2(100);

begin
proc2('Distributed Database');

end;
/